package de.mischok.academy.skiller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillerApplication.class, args);
	}

}
