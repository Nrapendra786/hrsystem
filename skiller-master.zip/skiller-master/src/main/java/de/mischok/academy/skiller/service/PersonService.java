package de.mischok.academy.skiller.service;

import de.mischok.academy.skiller.domain.Person;
import de.mischok.academy.skiller.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class PersonService {

    @Autowired
    private PersonRepository personRepository;

    public List<Person> getAllPersons() {
        return personRepository.findAll();
    }

    public List<Person> getAllPersonsWithComment() {
        // TODO: Implementation
        return Collections.emptyList();
    }

    public List<Person> getAllPersonsFromCountries(String...countries) {
        // TODO: Implementation
        return Collections.emptyList();
    }

    public List<String> getAllCountries() {
        // TODO: Implementation
        return Collections.emptyList();
    }

    public List<Person> getAllPersonsBornInTheEighties() {
        // TODO: Implementation
        return Collections.emptyList();
    }

    public Map<String, Long> getPersonCountByCountry() {
        // TODO: Implementation
        return Map.of();
    }

    public void deleteAll() {
        personRepository.deleteAll();
    }
}
