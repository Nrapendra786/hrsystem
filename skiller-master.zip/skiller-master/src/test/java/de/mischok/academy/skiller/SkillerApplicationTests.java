package de.mischok.academy.skiller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillerApplicationTests {

	@Test
	void contextLoads() {
	}

}
